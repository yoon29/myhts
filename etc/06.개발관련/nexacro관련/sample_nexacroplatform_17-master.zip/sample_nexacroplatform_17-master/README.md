# 넥사크로플랫폼 17 컴포넌트 활용 워크북 예제 프로젝트

![Product Version](https://img.shields.io/badge/nexacro%20platform-v17.1.2.200-blue.svg)

넥사크로플랫폼 17 컴포넌트 활용 워크북 문서 내 포함된 예제 프로젝트 저장소입니다.

> 컴포넌트 활용 워크북 문서는 다음 링크에서 볼 수 있습니다 (http://docs.tobesoft.com/developer_guide_nexacro_17_ko)

> 예제는 다음 링크에서 볼 수 있습니다. (http://demo.nexacro.com/developer_guide/17/guide.html)

> 온라인으로 제공하는 제품 도움말 전체 목록은 기술지원사이트 또는 TOBESOFT Online Document Library에서 확인할 수 있습니다. (http://docs.tobesoft.com)
